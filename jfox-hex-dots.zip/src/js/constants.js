export const constants = {
  SCENES: {
    LOAD: 'LOAD',
    GAME: 'GAME'
  }
}